import React  from 'react';
import './App.css';
import Search from './Component/ImageSearch';

function App() {
  return (
    <div className="App">
    {/* <h1>Image Search</h1> */}
    <Search/>
    </div>
  );
}

export default App;
